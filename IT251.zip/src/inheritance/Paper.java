/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author Administrator
 */
public class Paper extends Accounts{
    
     private double numberOfPounds=0.0;
     private double pricePerPound=10.0;
     private double totalPounds;

    public double getTotalPounds() {
        
        totalPounds = numberOfPounds * pricePerPound;
        
        return totalPounds;
    }

    public void setTotalPounds(double totalPounds) {
        this.totalPounds = totalPounds;
    }
            
            
    public double getNumberOfPounds() {
        return numberOfPounds;
    }

    public void setNumberOfPounds(double numberOfPounds) {
        this.numberOfPounds = numberOfPounds;
    }

    public double getPricePerPound() {
        return pricePerPound;
    }

    public void setPricePerPound (double pricePerPound) {
        this.pricePerPound = pricePerPound;
    }

    @Override
    public String toString() {
        return "Paper{" + "numberOfPounds = " + numberOfPounds 
                + ", pricePerPound = " + pricePerPound + 
                getAccountID() + super.toString() +  '}';
    }

    @Override
    public double computeSales() {
        return totalPounds;
    }

   
    
    
   
    
}
