/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author Administrator
 */
public class Inheritance {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
      Accounts a = new Supplies();
      a.setAccountID(23);
      a.setFirstName(" Eric  ");
      a.setLastName(" Carr  ");
      
      Supplies s = new Supplies();
      s.setAccountID(6);
      s.setSupplyID(14);
      s.setTotalSold(45);
      s.setFirstName(" Gaige  ");
      s.setLastName(" Cox  ");
      
      
      
      Services ser = new Services();
      ser.setAccountID(1);
      ser.setNumberOfHours(44);
      ser.setRatePerHours(4);
      ser.setFirstName(" Miohn  ");
      ser.setLastName(" Allen  ");
      
      
      Paper p = new Paper();
      p.setAccountID(2);
      p.setNumberOfPounds(60);
      p.setPricePerPound(4);
      p.setFirstName(" Deion  ");
      p.setLastName(" Johnson  ");
      
      System.out.println(a);
      System.out.println("Total sales equals: " + a.computeSales());
      System.out.println(s);
      System.out.println("Total Supplies equals: " + s.computeSales());
      System.out.println(ser);
      System.out.println("Total sales Service: " + ser.computeSales());
      System.out.println(p);
      System.out.println("Total sales Paper: " + p.computeSales());
    }
    
}
