/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author Administrator
 */
public class Services extends Accounts {
    
    private double numberOfHours= 8.0;
    private double ratePerHours= 0.0;
    private double totalHours;

    public double getTotalHours() {
        
        totalHours = numberOfHours * ratePerHours;
        return totalHours;
    }

    public void setTotalHours(double totalHours) {
        this.totalHours = totalHours;
    }
    
    
    public double getNumberOfHours() {
        return numberOfHours;
    }

    public void setNumberOfHours(double numberOfHours) {
        this.numberOfHours = numberOfHours;
    }

    public double getRatePerHours() {
        return ratePerHours;
    }

    public void setRatePerHours(double ratePerHours) {
        this.ratePerHours = ratePerHours;
    }

    @Override
    public String toString() {
        return "Services{" + "numberOfHours = " + numberOfHours 
                + ", ratePerHours = " + ratePerHours +
                getAccountID() + super.toString() + '}';
    }

    @Override
    public double computeSales() {
        return totalHours;
    }

   
 
    
 
        
    }

    

    

    
    

